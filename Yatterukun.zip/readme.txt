=== Yatterukun ===
Contributors: Katsuya Ando
Tags: http post, change media, replace media, replace image, replace video, chage image, change video, yatterukun
Donate link: https://paypal.me/yatterukun
Stable tag: 1.0.0
Tested up to: 5.3
Requires at least: 4.7
License: GPLv2 or later
License URI: https://www.gnu.org/licenses/old-licenses/gpl-2.0.html

Fast and easy photo/video media changer plugin.

== Description ==

Fast and easy photo/video media changer plugin.
Listening for HTTP POST upload on your specific page URL, 
and replace the target media file directly without wp-admin.

Upload picture/video from mobile phone, and you will be able to see the changes 
on your WordPress web site quick, right then.

In order to achieve this, This plugin modifies img/video tag in html
and prevent browser caching.

More details follow the link below;

https://www.andows.jp/yatterukun-wp/en

#### To go with custom header

Considering Custom Header is a WordPress theme's functionality,
Creating child theme is good, so we provided sample child themefor your convenience.

https://github.com/ankatsu2010/twentyseventeen-child-yatterukun

To prevent browser caching for custom header media, you need to create
your favorite theme's child like above.

#### Recommended mobile tool

For client side solution, "Yatterukun" mobile app is also available for free on Google Play and App Store.

How to use:
1.Take picture or select from album.
2.Tap "upload" button.
3.That should do it.
Let's go check it!

== Installation ==

You can install Yatterukun plugin directly from your WordPress dashboard:
 
 1. Go to the *Plugins* menu and click *Add New*.
 2. Search for *yatterukun*.
 3. Click *Install Now* next to the *yatterukun* plugin.
 4. Activate the plugin.
 5. Complete settings in *Yatterukun* in *Setting* menu.

== Screenshots ==

1. Settings page in English.
2. Settings page in Japanese.

== Changelog ==

= 1.0.0 =
* 2020-04-07 First release